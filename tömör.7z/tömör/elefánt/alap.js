fetch("https://raw.githubusercontent.com/siraly1636/siraly1636.github.io/main/elefant/assets/json/elefant.json")
.then(x => x.json())
.then(y => megjelenit(y));


function megjelenit(adatok){
    console.log(adatok);

    var sz="";
    for (elem of adatok){
        sz+='<div class="col-sm-12">';
        sz+='<div style="border:1px solid black;margin:20px;text-align:center;padding:20px;box-shadow:5px 5px 5px">';
        sz+=elem.name;
        sz+='<br>';
        sz+='<a href="'+elem.wikilink+'" target="_blank">Wikipedia!</a>';
        sz+='<br>';
        sz+='<img src="'+elem.image+'" alt="" style="width:100px">';
        sz+='</div>';
        sz+='</div>';

    }
    document.getElementById("tablazat").innerHTML=sz;


}